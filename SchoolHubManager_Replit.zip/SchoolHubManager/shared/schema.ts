import { pgTable, text, serial, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Role enum for user types
export const userRoleEnum = pgEnum('user_role', ['student', 'school', 'admin']);

// School types enum
export const schoolTypeEnum = pgEnum('school_type', ['public', 'private', 'charter', 'international']);

// Users table (for all user types)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Profile for students
export const studentProfiles = pgTable("student_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  grade: text("grade"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Profile for schools
export const schools = pgTable("schools", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: text("name").notNull(),
  type: schoolTypeEnum("type").notNull(),
  district: text("district"),
  adminFirstName: text("admin_first_name").notNull(),
  adminLastName: text("admin_last_name").notNull(),
  adminEmail: text("admin_email").notNull(),
  adminPhone: text("admin_phone"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Events table
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  eventType: text("event_type").notNull(),
  date: timestamp("date").notNull(),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  location: text("location"),
  schoolId: integer("school_id").references(() => schools.id, { onDelete: 'cascade' }).notNull(),
  capacity: integer("capacity"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Event registrations (students registered for events)
export const eventRegistrations = pgTable("event_registrations", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id, { onDelete: 'cascade' }).notNull(),
  studentId: integer("student_id").references(() => studentProfiles.id, { onDelete: 'cascade' }).notNull(),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true, updatedAt: true });

export const insertStudentProfileSchema = createInsertSchema(studentProfiles)
  .omit({ id: true, createdAt: true });

export const insertSchoolSchema = createInsertSchema(schools)
  .omit({ id: true, createdAt: true });

export const insertEventSchema = createInsertSchema(events)
  .omit({ id: true, createdAt: true });

export const insertEventRegistrationSchema = createInsertSchema(eventRegistrations)
  .omit({ id: true, registeredAt: true });

// Additional validation schemas for registration
// Base user schema without refinement
const baseUserSchema = z.object({
  username: z.string().min(3).max(50),
  email: z.string().email(),
  password: z.string().min(6),
  confirmPassword: z.string().min(6),
  role: z.enum(['student', 'school', 'admin']),
});

// Register user schema with refinement for password matching
export const registerUserSchema = baseUserSchema.refine(
  (data) => data.password === data.confirmPassword, 
  {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  }
);

// Student registration schema
export const registerStudentSchema = z.object({
  ...baseUserSchema.shape, 
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  grade: z.string().optional(),
}).refine(
  (data) => data.password === data.confirmPassword, 
  {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  }
);

// School registration schema
export const registerSchoolSchema = z.object({
  ...baseUserSchema.shape,
  name: z.string().min(1),
  type: z.enum(['public', 'private', 'charter', 'international']),
  district: z.string().optional(),
  adminFirstName: z.string().min(1),
  adminLastName: z.string().min(1),
  adminEmail: z.string().email(),
  adminPhone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  description: z.string().optional(),
}).refine(
  (data) => data.password === data.confirmPassword, 
  {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  }
);

export const loginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertStudentProfile = z.infer<typeof insertStudentProfileSchema>;
export type InsertSchool = z.infer<typeof insertSchoolSchema>;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type InsertEventRegistration = z.infer<typeof insertEventRegistrationSchema>;

export type User = typeof users.$inferSelect;
export type StudentProfile = typeof studentProfiles.$inferSelect;
export type School = typeof schools.$inferSelect;
export type Event = typeof events.$inferSelect;
export type EventRegistration = typeof eventRegistrations.$inferSelect;

export type LoginCredentials = z.infer<typeof loginSchema>;
export type RegisterStudent = z.infer<typeof registerStudentSchema>;
export type RegisterSchool = z.infer<typeof registerSchoolSchema>;

// Types with relations for frontend
export type UserWithProfile = User & {
  studentProfile?: StudentProfile;
  school?: School;
};

export type EventWithSchool = Event & {
  school: School;
};

export type SchoolWithEvents = School & {
  events: Event[];
};
