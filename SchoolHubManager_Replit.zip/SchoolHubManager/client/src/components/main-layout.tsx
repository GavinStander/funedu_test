import React from "react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Bell, 
  User, 
  LogOut, 
  Calendar, 
  MessageSquare, 
  Menu 
} from "lucide-react";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface MainLayoutProps {
  children: React.ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Get appropriate initial for avatar
  const getInitial = () => {
    if (!user) return "U";
    
    if (user.role === "student" && user.studentProfile) {
      return user.studentProfile.firstName.charAt(0);
    } else if (user.role === "school" && user.school) {
      return user.school.name.charAt(0);
    } else if (user.role === "admin") {
      return "A";
    }
    
    return user.username.charAt(0).toUpperCase();
  };

  const navLinks = [
    { name: "Dashboard", href: "/" },
    { name: "Calendar", href: "/calendar" },
    { name: "Messages", href: "/messages" },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Navigation */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Link href="/">
                  <h1 className="text-xl font-bold text-primary cursor-pointer">EduConnect</h1>
                </Link>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                {navLinks.map((link) => (
                  <Link key={link.name} href={link.href}>
                    <a
                      className={`${
                        location === link.href
                          ? "border-primary text-gray-900"
                          : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                      } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium h-full`}
                    >
                      {link.name}
                    </a>
                  </Link>
                ))}
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <Button variant="ghost" size="icon" className="mr-2">
                <Bell className="h-5 w-5" />
                <span className="sr-only">Notifications</span>
              </Button>

              {/* Profile dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="relative rounded-full h-8 w-8 bg-primary flex items-center justify-center text-white"
                  >
                    <span className="sr-only">Open user menu</span>
                    <span className="text-sm font-medium">{getInitial()}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Calendar className="mr-2 h-4 w-4" />
                    <span>Calendar</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    <span>Messages</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            
            {/* Mobile menu button */}
            <div className="flex items-center sm:hidden">
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left">
                  <div className="py-4">
                    <div className="px-2 pt-2 pb-3 space-y-1">
                      {navLinks.map((link) => (
                        <Link key={link.name} href={link.href}>
                          <a
                            className={`${
                              location === link.href
                                ? "bg-primary text-white"
                                : "text-gray-600 hover:bg-gray-100"
                            } block px-3 py-2 rounded-md text-base font-medium`}
                            onClick={() => setMobileMenuOpen(false)}
                          >
                            {link.name}
                          </a>
                        </Link>
                      ))}
                    </div>
                    <div className="pt-4 pb-3 border-t border-gray-200">
                      <div className="flex items-center px-5">
                        <div className="flex-shrink-0">
                          <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-white">
                            <span className="text-sm font-medium">{getInitial()}</span>
                          </div>
                        </div>
                        <div className="ml-3">
                          <div className="text-base font-medium text-gray-800">
                            {user?.username}
                          </div>
                          <div className="text-sm font-medium text-gray-500">
                            {user?.email}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="ml-auto">
                          <Bell className="h-6 w-6" />
                        </Button>
                      </div>
                      <div className="mt-3 px-2 space-y-1">
                        <Button
                          variant="ghost"
                          className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:bg-gray-100"
                        >
                          Profile
                        </Button>
                        <Button
                          variant="ghost"
                          className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-gray-600 hover:bg-gray-100"
                          onClick={handleLogout}
                        >
                          Logout
                        </Button>
                      </div>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {children}
        </div>
      </div>
    </div>
  );
}
