import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Event } from "@shared/schema";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { formatDateToLocale } from "@/lib/utils";
import { Pencil, EyeIcon, Trash } from "lucide-react";

interface EventTableProps {
  events: Event[];
  onEventCreated: () => void;
  limit?: number;
  showAll?: boolean;
}

export default function EventTable({ 
  events, 
  onEventCreated,
  limit = 5,
  showAll = false 
}: EventTableProps) {
  // Query to get event registrations count for each event
  const { data: registrationsData } = useQuery<Record<string, number>>({
    queryKey: ['/api/event-registrations/count'],
    enabled: events.length > 0,
  });

  // Apply limit if not showing all
  const displayEvents = showAll ? events : events.slice(0, limit);

  return (
    <div className="overflow-x-auto">
      {displayEvents.length > 0 ? (
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Registrations</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {displayEvents.map(event => {
              // Get registration count or default to 0
              const regCount = registrationsData?.[event.id.toString()] || 0;
              const capacity = event.capacity || 100;
              const regPercentage = Math.min(100, (regCount / capacity) * 100);
              
              // Determine if event is active based on date
              const eventDate = new Date(event.date);
              const isActive = eventDate >= new Date();
              
              return (
                <tr key={event.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{event.name}</div>
                    <div className="text-sm text-gray-500">{event.location}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{formatDateToLocale(event.date)}</div>
                    <div className="text-sm text-gray-500">{event.startTime} - {event.endTime}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                      {regCount} / {capacity}
                    </div>
                    <div className="h-1.5 w-24 bg-gray-200 rounded-full overflow-hidden">
                      <Progress value={regPercentage} className="h-full" />
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {isActive ? (
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    ) : (
                      <Badge variant="outline" className="text-gray-500">Completed</Badge>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex space-x-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Pencil className="h-4 w-4 text-blue-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <EyeIcon className="h-4 w-4 text-gray-600" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Trash className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : (
        <p className="text-gray-500 text-center py-8">No events found. Create your first event!</p>
      )}
    </div>
  );
}
