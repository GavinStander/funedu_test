import { useQuery } from "@tanstack/react-query";
import { UserWithProfile, EventWithSchool, School } from "@shared/schema";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent } from "@/components/ui/card";
import {
  School as SchoolIcon,
  CalendarDays,
  User,
  Building2,
  MapPin,
  Phone,
  Globe,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface StudentDashboardProps {
  user: UserWithProfile;
}

export function StudentDashboard({ user }: StudentDashboardProps) {
  const { toast } = useToast();
  const [registeredEvents, setRegisteredEvents] = useState<number[]>([]);

  // Get the school if the student is associated with one
  const schoolId = user.studentProfile?.schoolId;

  const { data: school, isLoading: isLoadingSchool } = useQuery<School>({
    queryKey: schoolId ? [`/api/schools/${schoolId}`] : null,
    enabled: !!schoolId,
  });

  // Get all events for the student's school
  const { data: events = [], isLoading: isLoadingEvents } = useQuery<
    EventWithSchool[]
  >({
    queryKey: schoolId ? [`/api/schools/${schoolId}/events`] : ["/api/events"],
  });

  // Register for an event
  const registerForEvent = async (eventId: number) => {
    try {
      await apiRequest("POST", `/api/events/${eventId}/register`);
      setRegisteredEvents((prev) => [...prev, eventId]);
      toast({
        title: "Success",
        description: "You've been registered for this event.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to register for the event.",
        variant: "destructive",
      });
    }
  };

  const isRegistered = (eventId: number) => registeredEvents.includes(eventId);

  const formatEventDate = (date: string) => {
    try {
      return format(new Date(date), "MMMM d, yyyy");
    } catch (e) {
      return date;
    }
  };

  const getEventBadgeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case "academic":
        return "bg-green-100 text-green-800";
      case "arts & music":
        return "bg-purple-100 text-purple-800";
      case "athletics":
        return "bg-blue-100 text-blue-800";
      case "career development":
        return "bg-blue-100 text-blue-800";
      case "community service":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">
        Student Dashboard
      </h1>

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {/* School Info Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary rounded-md p-3">
                <SchoolIcon className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                {isLoadingSchool ? (
                  <Skeleton className="h-10 w-40" />
                ) : (
                  <>
                    <p className="text-sm font-medium text-gray-500 truncate">
                      Your School
                    </p>
                    <p className="text-lg font-medium text-gray-900">
                      {school?.name || "Not assigned to a school"}
                    </p>
                  </>
                )}
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              {schoolId ? (
                <Button
                  variant="link"
                  className="p-0 text-primary hover:text-indigo-800"
                >
                  View school details
                </Button>
              ) : (
                <span className="text-gray-500">No school assigned</span>
              )}
            </div>
          </div>
        </Card>

        {/* Upcoming Events Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-secondary rounded-md p-3">
                <CalendarDays className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  Upcoming Events
                </p>
                <p className="text-lg font-medium text-gray-900">
                  {isLoadingEvents ? (
                    <Skeleton className="h-6 w-24" />
                  ) : (
                    `${events.length} events`
                  )}
                </p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
              >
                View all events
              </Button>
            </div>
          </div>
        </Card>

        {/* Profile Completion Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-orange-500 rounded-md p-3">
                <User className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  Profile Completion
                </p>
                <p className="text-lg font-medium text-gray-900">85%</p>
              </div>
            </div>
            <div className="mt-4 w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-green-500 h-2.5 rounded-full"
                style={{ width: "85%" }}
              ></div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
              >
                Complete your profile
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* School Events */}
      <h2 className="mt-8 text-lg font-medium text-gray-900">
        Upcoming School Events
      </h2>
      {isLoadingEvents ? (
        <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-4" />
                <Skeleton className="h-12 w-full mb-4" />
                <Skeleton className="h-5 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : events.length === 0 ? (
        <p className="mt-4 text-gray-500">No upcoming events.</p>
      ) : (
        <div className="mt-2 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {events.map((event) => (
            <Card key={event.id}>
              <CardContent className="px-4 py-5 sm:p-6">
                <div className="flex items-center mb-4">
                  <div className="flex-shrink-0">
                    <CalendarDays className="h-5 w-5 text-secondary" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-gray-900">
                      {event.title}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {formatEventDate(event.date.toString())} •{" "}
                      {event.startTime} - {event.endTime}
                    </p>
                  </div>
                </div>
                <p className="text-sm text-gray-600">{event.description}</p>
                <div className="mt-4">
                  <Badge className={getEventBadgeColor(event.eventType)}>
                    {event.eventType}
                  </Badge>
                </div>
              </CardContent>
              <div className="bg-gray-50 px-4 py-4 sm:px-6">
                <div className="flex justify-between">
                  <div className="text-sm">
                    <span className="text-gray-500">{event.location}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => registerForEvent(event.id)}
                    disabled={isRegistered(event.id)}
                    className="inline-flex items-center px-3 py-1 text-sm leading-4 font-medium rounded-md text-primary bg-indigo-50 hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    {isRegistered(event.id) ? "Registered" : "RSVP"}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* School Information */}
      {school && (
        <>
          <h2 className="mt-8 text-lg font-medium text-gray-900">
            School Information
          </h2>
          <Card className="mt-2">
            <div className="px-4 py-5 sm:px-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">
                {school.name}
              </h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">
                {school.address}, {school.city}, {school.state} {school.zipCode}
              </p>
            </div>
            <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
              <dl className="sm:divide-y sm:divide-gray-200">
                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt className="text-sm font-medium text-gray-500 flex items-center">
                    <Building2 className="h-4 w-4 mr-1" /> School Type
                  </dt>
                  <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    {school.type.charAt(0).toUpperCase() + school.type.slice(1)}{" "}
                    School
                  </dd>
                </div>
                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt className="text-sm font-medium text-gray-500 flex items-center">
                    <Users className="h-4 w-4 mr-1" /> Administrator
                  </dt>
                  <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    {school.adminFirstName} {school.adminLastName}
                  </dd>
                </div>
                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt className="text-sm font-medium text-gray-500 flex items-center">
                    <Phone className="h-4 w-4 mr-1" /> Contact
                  </dt>
                  <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    {school.adminPhone || "N/A"}
                  </dd>
                </div>
                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                  <dt className="text-sm font-medium text-gray-500 flex items-center">
                    <MapPin className="h-4 w-4 mr-1" /> Location
                  </dt>
                  <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                    {school.address}, {school.city}, {school.state}{" "}
                    {school.zipCode}
                  </dd>
                </div>
                {school.description && (
                  <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">About</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                      {school.description}
                    </dd>
                  </div>
                )}
              </dl>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}
