import { useQuery } from "@tanstack/react-query";
import { UserWithProfile, School, User, Event } from "@shared/schema";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Users, Building, CalendarDays, UserPlus,
  Clock, School as SchoolIcon, User as UserIcon,
  CalendarCheck, Building2, Eye
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

interface AdminDashboardProps {
  user: UserWithProfile;
}

export function AdminDashboard({ user }: AdminDashboardProps) {
  // Get all schools
  const { data: schools = [], isLoading: isLoadingSchools } = useQuery<School[]>({
    queryKey: ['/api/schools'],
  });
  
  // For the mock data, we'll use placeholder values
  const totalStudents = 8472;
  const totalEvents = 127;
  const newRegistrations = 18;
  
  // School columns for the data table
  const schoolColumns = [
    {
      header: "School",
      accessorKey: (school: School) => (
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 bg-primary rounded-full flex items-center justify-center text-white">
            <span>{school.name.charAt(0)}</span>
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">{school.name}</div>
            <div className="text-sm text-gray-500">{school.city}, {school.state}</div>
          </div>
        </div>
      ),
    },
    {
      header: "Type",
      accessorKey: (school: School) => (
        <div className="text-sm text-gray-900">{school.type.charAt(0).toUpperCase() + school.type.slice(1)}</div>
      ),
    },
    {
      header: "Students",
      accessorKey: (school: School) => (
        <span className="text-sm text-gray-500">
          {/* This would be fetched from an API call */}
          {Math.floor(Math.random() * 1000) + 500}
        </span>
      ),
    },
    {
      header: "Events",
      accessorKey: (school: School) => (
        <span className="text-sm text-gray-500">
          {/* This would be fetched from an API call */}
          {Math.floor(Math.random() * 15) + 5}
        </span>
      ),
    },
    {
      header: "Status",
      accessorKey: (school: School) => (
        <Badge className="bg-green-100 text-green-800 px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
          Active
        </Badge>
      ),
    },
    {
      header: "Actions",
      accessorKey: (school: School) => (
        <div className="text-right">
          <Button variant="ghost" size="sm" className="text-primary hover:text-indigo-800">
            <Eye className="h-4 w-4 mr-1" />
            View
          </Button>
        </div>
      ),
    },
  ];
  
  // Mock recent activity data
  const recentActivities = [
    { 
      id: 1, 
      type: 'student-register', 
      content: ' High School',
      time: '10m ago',
      icon: <UserPlus className="h-4 w-4 text-white" />,
      iconBg: 'bg-green-500'
    },
    { 
      id: 2, 
      type: 'event-created', 
      content: 'Washington Academy created a new event Spring Concert',
      time: '45m ago',
      icon: <CalendarDays className="h-4 w-4 text-white" />,
      iconBg: 'bg-primary'
    },
    { 
      id: 3, 
      type: 'school-register', 
      content: 'New school Jefferson Academy registered',
      time: '2h ago',
      icon: <SchoolIcon className="h-4 w-4 text-white" />,
      iconBg: 'bg-secondary'
    },
    { 
      id: 4, 
      type: 'event-full', 
      content: 'Science Fair at Central High reached capacity with 100 registrations',
      time: '3h ago',
      icon: <CalendarCheck className="h-4 w-4 text-white" />,
      iconBg: 'bg-orange-500'
    }
  ];
  
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Admin Dashboard</h1>
      
      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Students Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary rounded-md p-3">
                <Users className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">Total Students</p>
                <p className="text-lg font-medium text-gray-900">{totalStudents.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button variant="link" className="p-0 text-primary hover:text-indigo-800">
                View all students
              </Button>
            </div>
          </div>
        </Card>

        {/* Schools Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-secondary rounded-md p-3">
                <Building className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">Total Schools</p>
                <p className="text-lg font-medium text-gray-900">
                  {isLoadingSchools ? <Skeleton className="h-6 w-8" /> : schools.length}
                </p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button variant="link" className="p-0 text-primary hover:text-indigo-800">
                View all schools
              </Button>
            </div>
          </div>
        </Card>

        {/* Events Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-orange-500 rounded-md p-3">
                <CalendarDays className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">Active Events</p>
                <p className="text-lg font-medium text-gray-900">{totalEvents}</p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button variant="link" className="p-0 text-primary hover:text-indigo-800">
                View all events
              </Button>
            </div>
          </div>
        </Card>

        {/* New Registrations Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                <UserPlus className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">New Registrations</p>
                <p className="text-lg font-medium text-gray-900">{newRegistrations}</p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button variant="link" className="p-0 text-primary hover:text-indigo-800">
                Review registrations
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Data Tabs */}
      <div className="mt-8">
        <Tabs defaultValue="schools">
          <TabsList className="border-b border-gray-200 w-full justify-start space-x-8">
            <TabsTrigger value="schools" className="px-1 py-4 data-[state=active]:border-primary data-[state=active]:text-primary">
              Schools
            </TabsTrigger>
            <TabsTrigger value="students" className="px-1 py-4 data-[state=active]:border-primary data-[state=active]:text-primary">
              Students
            </TabsTrigger>
            <TabsTrigger value="events" className="px-1 py-4 data-[state=active]:border-primary data-[state=active]:text-primary">
              Events
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="schools" className="mt-4">
            {isLoadingSchools ? (
              <Skeleton className="h-64 w-full" />
            ) : (
              <DataTable 
                data={schools}
                columns={schoolColumns}
                emptyState={
                  <div className="text-center py-8">
                    <Building2 className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No schools</h3>
                    <p className="mt-1 text-sm text-gray-500">No schools have registered yet.</p>
                  </div>
                }
              />
            )}
          </TabsContent>
          
          <TabsContent value="students">
            <div className="text-center py-8">
              <UserIcon className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Students tab</h3>
              <p className="mt-1 text-sm text-gray-500">View and manage all students here.</p>
            </div>
          </TabsContent>
          
          <TabsContent value="events">
            <div className="text-center py-8">
              <CalendarDays className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Events tab</h3>
              <p className="mt-1 text-sm text-gray-500">View and manage all events here.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Recent Activity */}
      <h2 className="mt-8 text-lg font-medium text-gray-900">Recent Activity</h2>
      <div className="mt-2 flow-root">
        <ul role="list" className="-mb-8">
          {recentActivities.map((activity, idx) => (
            <li key={activity.id}>
              <div className="relative pb-8">
                {idx !== recentActivities.length - 1 && (
                  <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" aria-hidden="true"></span>
                )}
                <div className="relative flex space-x-3">
                  <div>
                    <span className={`h-8 w-8 rounded-full ${activity.iconBg} flex items-center justify-center ring-8 ring-white`}>
                      {activity.icon}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                    <div>
                      <p className="text-sm text-gray-500">
                        {activity.content}
                      </p>
                    </div>
                    <div className="text-right text-sm whitespace-nowrap text-gray-500">
                      {activity.time}
                    </div>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
