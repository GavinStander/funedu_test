import { useQuery, useMutation } from "@tanstack/react-query";
import { UserWithProfile, Event } from "@shared/schema";
import { DataTable } from "@/components/ui/data-table";
import { Card, CardContent } from "@/components/ui/card";
import {
  Users,
  CalendarDays,
  MessageSquare,
  School,
  Edit,
  Trash2,
  PlusCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { EventForm } from "@/components/forms/event-form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";

interface SchoolDashboardProps {
  user: UserWithProfile;
}

export function SchoolDashboard({ user }: SchoolDashboardProps) {
  const { toast } = useToast();
  const [isCreateEventOpen, setIsCreateEventOpen] = useState(false);

  const schoolId = user.school?.id;

  // Get school details
  const { data: school } = useQuery({
    queryKey: [`/api/schools/${schoolId}`],
    enabled: !!schoolId,
  });

  // Get events for this school
  const { data: events = [], isLoading: isLoadingEvents } = useQuery<Event[]>({
    queryKey: schoolId ? [`/api/schools/${schoolId}/events`] : null,
    enabled: !!schoolId,
    select: (data) => {
      return [...data].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      );
    },
  });

  // Fetch the student count for the school
  const { data: studentCount = 0, isLoading: isLoadingStudentCount } = useQuery({
    queryKey: [`/api/schools/${schoolId}/students/count`],
    enabled: !!schoolId, // Only fetch if schoolId exists
  });

  // Create event mutation
  const createEventMutation = useMutation({
    mutationFn: async (eventData: any) => {
      const res = await apiRequest("POST", "/api/events", eventData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [`/api/schools/${schoolId}/events`],
      });
      setIsCreateEventOpen(false);
      toast({
        title: "Success",
        description: "Event created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create event: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Format date for display
  const formatEventDate = (date: string) => {
    try {
      return format(new Date(date), "MMMM d, yyyy");
    } catch (e) {
      return date;
    }
  };

  // Columns for events table
  const eventColumns = [
    {
      header: "Event Name",
      accessorKey: (event: Event) => (
        <div className="flex items-center">
          <div className="flex-shrink-0 h-10 w-10 bg-secondary rounded-full flex items-center justify-center text-white">
            <CalendarDays className="h-5 w-5" />
          </div>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">
              {event.title}
            </div>
            <div className="text-sm text-gray-500">{event.eventType}</div>
          </div>
        </div>
      ),
    },
    {
      header: "Date & Time",
      accessorKey: (event: Event) => (
        <div>
          <div className="text-sm text-gray-900">
            {formatEventDate(event.date.toString())}
          </div>
          <div className="text-sm text-gray-500">
            {event.startTime} - {event.endTime}
          </div>
        </div>
      ),
    },
    {
      header: "Location",
      accessorKey: "location",
      cell: (event: Event) => (
        <span className="text-sm text-gray-500">{event.location}</span>
      ),
    },
    {
      header: "Attendees",
      accessorKey: (event: Event) => (
        <span className="text-sm text-gray-500">
          {/* This would be populated from eventRegistrations count */}0 /{" "}
          {event.capacity || "∞"}
        </span>
      ),
    },
    {
      header: "Status",
      accessorKey: (event: Event) => (
        <Badge className="bg-green-100 text-green-800 px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
          Active
        </Badge>
      ),
    },
    {
      header: "Actions",
      accessorKey: (event: Event) => (
        <div className="text-right space-x-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-primary hover:text-indigo-800"
          >
            <Edit className="h-4 w-4" />
            <span className="sr-only">Edit</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-red-500 hover:text-red-800"
          >
            <Trash2 className="h-4 w-4" />
            <span className="sr-only">Delete</span>
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">
        {school?.name || "School"} Dashboard
      </h1>

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {/* Students Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary rounded-md p-3">
                <Users className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  Total Students
                </p>
                <p className="text-lg font-medium text-gray-900">
                  {isLoadingStudentCount ? (
                    <Skeleton className="h-6 w-8" />
                  ) : (
                    studentCount
                  )}
                </p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
              >
                View all students
              </Button>
            </div>
          </div>
        </Card>

        {/* Events Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-secondary rounded-md p-3">
                <CalendarDays className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  Active Events
                </p>
                <p className="text-lg font-medium text-gray-900">
                  {isLoadingEvents ? (
                    <Skeleton className="h-6 w-8" />
                  ) : (
                    events.length
                  )}
                </p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
                onClick={() => setIsCreateEventOpen(true)}
              >
                Manage events
              </Button>
            </div>
          </div>
        </Card>

        {/* Messages Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-orange-500 rounded-md p-3">
                <MessageSquare className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  New Messages
                </p>
                <p className="text-lg font-medium text-gray-900">18</p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
              >
                View messages
              </Button>
            </div>
          </div>
        </Card>

        {/* Profile Status Card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                <School className="h-5 w-5 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <p className="text-sm font-medium text-gray-500 truncate">
                  Profile Status
                </p>
                <p className="text-lg font-medium text-gray-900">Complete</p>
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Button
                variant="link"
                className="p-0 text-primary hover:text-indigo-800"
              >
                Update profile
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* Create Event Section */}
      <Dialog open={isCreateEventOpen} onOpenChange={setIsCreateEventOpen}>
        <DialogTrigger asChild>
          <div className="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
              <div>
                <h3 className="text-lg leading-6 font-medium text-gray-900">
                  Create New Event
                </h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                  Add a new event for your students
                </p>
              </div>
              <Button
                onClick={() => setIsCreateEventOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Event
              </Button>
            </div>
          </div>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Event</DialogTitle>
            <DialogDescription>
              Fill in the details to create a new event for your school.
            </DialogDescription>
          </DialogHeader>
          <EventForm
            onSubmit={(data) => createEventMutation.mutate(data)}
            isPending={createEventMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Manage Events */}
      <h2 className="mt-8 text-lg font-medium text-gray-900">
        Upcoming Events
      </h2>
      {isLoadingEvents ? (
        <div className="mt-4">
          <Skeleton className="h-64 w-full" />
        </div>
      ) : events.length === 0 ? (
        <div className="mt-4 text-center py-8 bg-white rounded-lg shadow border border-gray-200">
          <CalendarDays className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No events</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating a new event.
          </p>
          <div className="mt-6">
            <Button onClick={() => setIsCreateEventOpen(true)}>
              <PlusCircle className="mr-2 h-4 w-4" />
              Create Event
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-2 flex flex-col transition-all duration-200 ease-in-out">
          <DataTable
            data={events}
            columns={eventColumns}
            className="animate-in fade-in duration-300"
            emptyState={
              <div className="text-center py-8">
                <CalendarDays className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">
                  No events
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Get started by creating a new event.
                </p>
                <div className="mt-6">
                  <Button onClick={() => setIsCreateEventOpen(true)}>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Create Event
                  </Button>
                </div>
              </div>
            }
          />
        </div>
      )}
    </div>
  );
}
