import { Student } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TableHeader, TableRow, TableHead, TableBody, TableCell, Table } from "@/components/ui/table";
import { formatDateToLocale } from "@/lib/utils";

interface StudentTableProps {
  students: Student[];
  limit?: number;
}

export default function StudentTable({ students, limit }: StudentTableProps) {
  // Limit the number of students displayed if limit is provided
  const displayStudents = limit ? students.slice(0, limit) : students;
  
  return (
    <div>
      {displayStudents.length > 0 ? (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead>Joined Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-primary font-semibold mr-3">
                        <span>{getInitials(student.firstName, student.lastName)}</span>
                      </div>
                      <div>
                        <div className="font-medium">{student.firstName} {student.lastName}</div>
                        <div className="text-sm text-gray-500">ID: {student.id}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{formatGrade(student.grade)}</TableCell>
                  <TableCell>{formatDateToLocale(student.dateOfBirth)}</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" className="text-blue-600 hover:text-blue-900">
                        Edit
                      </Button>
                      <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                        View
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="text-gray-500 text-center py-8">No students found.</p>
      )}
    </div>
  );
}

// Helper function to get initials from first and last name
function getInitials(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`;
}

// Helper function to format grade
function formatGrade(grade: string): string {
  if (grade.startsWith('college')) {
    const year = grade.replace('college', '');
    return `College - Year ${year}`;
  }
  return `${grade}th Grade`;
}
