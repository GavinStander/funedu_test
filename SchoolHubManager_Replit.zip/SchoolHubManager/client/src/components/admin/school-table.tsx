import { School } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TableHeader, TableRow, TableHead, TableBody, TableCell, Table } from "@/components/ui/table";

interface SchoolTableProps {
  schools: School[];
  limit?: number;
}

export default function SchoolTable({ schools, limit }: SchoolTableProps) {
  // Limit the number of schools displayed if limit is provided
  const displaySchools = limit ? schools.slice(0, limit) : schools;
  
  return (
    <div>
      {displaySchools.length > 0 ? (
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displaySchools.map((school) => (
                <TableRow key={school.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-md bg-blue-100 flex items-center justify-center text-primary font-semibold mr-3">
                        <span>{getInitials(school.name)}</span>
                      </div>
                      <div>
                        <div className="font-medium">{school.name}</div>
                        <div className="text-sm text-gray-500">ID: SCH-{school.id.toString().padStart(4, '0')}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{formatSchoolType(school.type)}</TableCell>
                  <TableCell>
                    <div className="text-sm">
                      <div>{school.website || "No website provided"}</div>
                      <div className="text-gray-500">{school.address || "No address provided"}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Active</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="ghost" className="text-blue-600 hover:text-blue-900">
                        Edit
                      </Button>
                      <Button variant="ghost" className="text-gray-600 hover:text-gray-900">
                        View
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="text-gray-500 text-center py-8">No schools found.</p>
      )}
    </div>
  );
}

// Helper function to get initials from school name
function getInitials(name: string): string {
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();
}

// Helper function to format school type
function formatSchoolType(type: string): string {
  const typeMap: Record<string, string> = {
    highSchool: 'High School',
    university: 'University/College',
    vocational: 'Vocational/Technical Institute',
    other: 'Other Educational Institution'
  };
  
  return typeMap[type] || type;
}
