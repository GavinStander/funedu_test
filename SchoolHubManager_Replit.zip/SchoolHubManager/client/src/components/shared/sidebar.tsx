import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { School, Graduation, Users, Calendar, Home, HelpCircle, Settings, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "../ui/button";

type UserType = 'student' | 'school' | 'admin';

type SidebarProps = {
  userType: UserType;
  userName: string;
  activeTab: string;
  onTabChange: (tab: string) => void;
};

export default function Sidebar({ userType, userName, activeTab, onTabChange }: SidebarProps) {
  const { logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    setLocation('/auth');
  };

  // Color scheme based on user type
  const colorScheme = {
    student: {
      primaryColor: 'text-primary',
      accentBg: 'bg-blue-50',
      accentBorder: 'border-primary',
      hoverBg: 'hover:bg-blue-50',
      hoverText: 'hover:text-primary',
      iconBg: 'bg-blue-100',
    },
    school: {
      primaryColor: 'text-green-600',
      accentBg: 'bg-green-50',
      accentBorder: 'border-green-600',
      hoverBg: 'hover:bg-green-50',
      hoverText: 'hover:text-green-600',
      iconBg: 'bg-green-100',
    },
    admin: {
      primaryColor: 'text-purple-600',
      accentBg: 'bg-purple-50',
      accentBorder: 'border-purple-600',
      hoverBg: 'hover:bg-purple-50',
      hoverText: 'hover:text-purple-600',
      iconBg: 'bg-purple-100',
    }
  };

  const colors = colorScheme[userType];

  // Navigation items based on user type
  const navItems = {
    student: [
      { icon: <Home className="h-5 w-5" />, label: 'Dashboard', tab: 'dashboard' },
      { icon: <School className="h-5 w-5" />, label: 'Schools', tab: 'schools' },
      { icon: <Calendar className="h-5 w-5" />, label: 'Events', tab: 'events' },
      { icon: <HelpCircle className="h-5 w-5" />, label: 'Help', tab: 'help' },
    ],
    school: [
      { icon: <Home className="h-5 w-5" />, label: 'Dashboard', tab: 'dashboard' },
      { icon: <Graduation className="h-5 w-5" />, label: 'Students', tab: 'students' },
      { icon: <Calendar className="h-5 w-5" />, label: 'Events', tab: 'events' },
      { icon: <Settings className="h-5 w-5" />, label: 'Settings', tab: 'settings' },
    ],
    admin: [
      { icon: <Home className="h-5 w-5" />, label: 'Dashboard', tab: 'dashboard' },
      { icon: <Users className="h-5 w-5" />, label: 'Students', tab: 'students' },
      { icon: <School className="h-5 w-5" />, label: 'Schools', tab: 'schools' },
      { icon: <Calendar className="h-5 w-5" />, label: 'Events', tab: 'events' },
      { icon: <Settings className="h-5 w-5" />, label: 'Settings', tab: 'settings' },
    ]
  };

  return (
    <div className="w-64 bg-white shadow-md">
      <div className="p-4 border-b">
        <h2 className={cn("text-2xl font-bold", colors.primaryColor)}>
          {userType === 'admin' ? 'EduConnect Admin' : 'EduConnect'}
        </h2>
      </div>
      
      <div className="py-4">
        <div className="px-4 mb-6">
          <div className="flex items-center space-x-3">
            <div className={cn("w-10 h-10 rounded-full flex items-center justify-center text-primary font-semibold", colors.iconBg, colors.primaryColor)}>
              <span>{userName.substring(0, 2).toUpperCase()}</span>
            </div>
            <div>
              <h3 className="font-medium text-gray-800">{userName}</h3>
              <p className="text-sm text-gray-500 capitalize">{userType}</p>
            </div>
          </div>
        </div>
        
        <nav className="space-y-1">
          {navItems[userType].map((item) => (
            <a
              key={item.tab}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onTabChange(item.tab);
              }}
              className={cn(
                "flex items-center px-4 py-3",
                activeTab === item.tab
                  ? `text-gray-800 ${colors.accentBg} border-l-4 ${colors.accentBorder}`
                  : `text-gray-600 ${colors.hoverBg} ${colors.hoverText}`
              )}
            >
              <span className={cn("mr-3", activeTab === item.tab ? colors.primaryColor : "")}>{item.icon}</span>
              {item.label}
            </a>
          ))}
          
          <Button
            variant="ghost"
            className="flex w-full items-center px-4 py-3 text-gray-600 hover:bg-red-50 hover:text-red-600 justify-start rounded-none"
            onClick={handleLogout}
          >
            <LogOut className="mr-3 h-5 w-5" />
            Logout
          </Button>
        </nav>
      </div>
    </div>
  );
}
