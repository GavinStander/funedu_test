import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, LoginCredentials } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface LoginFormProps {
  onSubmit: (data: LoginCredentials) => void;
  isPending: boolean;
  onShowRegistration: () => void;
  onSwitchUserType: (type: string) => void;
}

export function LoginForm({ onSubmit, isPending, onShowRegistration, onSwitchUserType }: LoginFormProps) {
  const form = useForm<LoginCredentials>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email Address or Username</FormLabel>
              <FormControl>
                <Input placeholder="your@email.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Checkbox id="remember-me" />
            <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700">
              Remember me
            </label>
          </div>
          <Button variant="link" className="p-0 text-primary hover:text-indigo-800">
            Forgot password?
          </Button>
        </div>
        
        <Button 
          type="submit" 
          className="w-full"
          disabled={isPending}
        >
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Signing in...
            </>
          ) : (
            "Sign In"
          )}
        </Button>
        
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <Separator className="w-full" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">Or continue as</span>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={() => onSwitchUserType('student')}
            className="flex items-center justify-center py-2 px-4"
          >
            Student
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => onSwitchUserType('school')}
            className="flex items-center justify-center py-2 px-4"
          >
            School
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => onSwitchUserType('admin')}
            className="flex items-center justify-center py-2 px-4"
          >
            Admin
          </Button>
        </div>
        
        <p className="text-center text-sm text-gray-600">
          Don't have an account?{" "}
          <Button 
            variant="link" 
            className="p-0 text-primary hover:text-indigo-800 font-medium"
            onClick={onShowRegistration}
          >
            Register here
          </Button>
        </p>
      </form>
    </Form>
  );
}
