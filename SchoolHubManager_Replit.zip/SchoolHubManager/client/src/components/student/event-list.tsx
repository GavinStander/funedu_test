import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EventRegistration, Event } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";

interface EventListProps {
  registrations: EventRegistration[];
  title: string;
  className?: string;
  showAll?: boolean;
  limit?: number;
}

export default function EventList({ 
  registrations, 
  title, 
  className,
  showAll = false,
  limit = 5
}: EventListProps) {
  
  // Dynamic query to fetch all events referenced in the registrations
  const eventIds = registrations?.map(reg => reg.eventId) || [];
  
  const { data: events } = useQuery<Event[]>({
    queryKey: ['/api/events'],
    enabled: eventIds.length > 0,
  });

  // Match events with registrations
  const eventsWithStatus = events?.map(event => {
    const registration = registrations.find(reg => reg.eventId === event.id);
    return {
      ...event,
      status: registration?.status || "not-registered"
    };
  }) || [];

  // Limit the number of events shown if not showing all
  const displayEvents = showAll ? eventsWithStatus : eventsWithStatus.slice(0, limit);

  return (
    <Card className={cn("", className)}>
      <div className="px-6 py-4 border-b">
        <h2 className="text-xl font-semibold">{title}</h2>
      </div>
      <CardContent className="p-6">
        {displayEvents.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {displayEvents.map(event => (
                  <tr key={event.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{event.name}</div>
                      <div className="text-sm text-gray-500">{event.location}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{new Date(event.date).toLocaleDateString()}</div>
                      <div className="text-sm text-gray-500">{event.startTime} - {event.endTime}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <StatusBadge status={event.status} />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <Button variant="link" className="text-primary hover:text-blue-700">
                        View Details
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500 text-center py-8">No events found.</p>
        )}
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case "registered":
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Registered</Badge>;
    case "pending":
      return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>;
    case "cancelled":
      return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Cancelled</Badge>;
    default:
      return <Badge variant="outline">Not Registered</Badge>;
  }
}
