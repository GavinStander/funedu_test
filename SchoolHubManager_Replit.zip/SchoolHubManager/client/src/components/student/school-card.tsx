import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { School } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SchoolCardProps {
  school: School;
  isConnected?: boolean;
  studentId?: number;
}

export default function SchoolCard({ school, isConnected, studentId }: SchoolCardProps) {
  const { toast } = useToast();
  
  // School types mapped to more readable format
  const schoolTypeMap: Record<string, string> = {
    highSchool: 'High School',
    university: 'University/College',
    vocational: 'Vocational/Technical Institute',
    other: 'Educational Institution'
  };
  
  // Format school type for display
  const formattedType = schoolTypeMap[school.type] || school.type;

  // Connect to school mutation
  const connectMutation = useMutation({
    mutationFn: async () => {
      if (!studentId) throw new Error("Student ID is required");
      
      const res = await apiRequest("POST", "/api/school-connections", {
        schoolId: school.id,
        studentId: studentId,
        status: "connected" // Default status when connecting
      });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Connected!",
        description: `You are now connected to ${school.name}`,
      });
      // Invalidate connections query to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/students/${studentId}/connections`] });
    },
    onError: (error) => {
      toast({
        title: "Connection failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Generate school initials from name
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  return (
    <Card className="border rounded-lg overflow-hidden">
      <div className="h-40 bg-blue-100 relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-4xl font-bold text-primary/20">{getInitials(school.name)}</div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-gray-900 p-4">
          <h3 className="text-white font-semibold">{school.name}</h3>
        </div>
      </div>
      <div className="p-4">
        <div className="text-sm text-gray-500 mb-2">{formattedType}</div>
        <p className="text-sm text-gray-600 mb-4">
          {school.description || `A ${formattedType.toLowerCase()} offering educational programs and activities.`}
        </p>
        <div className="flex justify-between items-center">
          {isConnected ? (
            <Badge className="bg-green-100 text-green-800">Connected</Badge>
          ) : (
            <span className="text-xs text-gray-500">Not connected</span>
          )}
          
          {isConnected ? (
            <Button variant="link" className="text-primary hover:underline">
              View Profile
            </Button>
          ) : (
            <Button 
              variant="outline" 
              size="sm" 
              className="text-primary border-primary hover:bg-primary/10"
              onClick={() => connectMutation.mutate()}
              disabled={connectMutation.isPending}
            >
              {connectMutation.isPending ? "Connecting..." : "Connect"}
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}
