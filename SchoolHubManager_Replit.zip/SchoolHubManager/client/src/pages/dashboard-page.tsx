import { useAuth } from "@/hooks/use-auth";
import { MainLayout } from "@/components/main-layout";
import { StudentDashboard } from "@/components/dashboard/student-dashboard";
import { SchoolDashboard } from "@/components/dashboard/school-dashboard";
import { AdminDashboard } from "@/components/dashboard/admin-dashboard";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null; // The ProtectedRoute component will handle redirection
  }

  return (
    <MainLayout>
      {user.role === "student" && <StudentDashboard user={user} />}
      {user.role === "school" && <SchoolDashboard user={user} />}
      {user.role === "admin" && <AdminDashboard user={user} />}
    </MainLayout>
  );
}
