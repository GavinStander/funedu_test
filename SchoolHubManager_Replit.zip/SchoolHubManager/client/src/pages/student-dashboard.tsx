import { useEffect, useState } from "react";
import Sidebar from "@/components/shared/sidebar";
import EventList from "@/components/student/event-list";
import SchoolCard from "@/components/student/school-card";
import { Card, CardContent } from "@/components/ui/card";
import { 
  School, 
  Event, 
  EventRegistration,
  SchoolConnection 
} from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

export default function StudentDashboard() {
  const { user } = useAuth();
  const studentId = user?.studentId;
  
  const [activeTab, setActiveTab] = useState<'dashboard' | 'schools' | 'events'>('dashboard');

  // Fetch student connections (connected schools)
  const { 
    data: connections,
    isLoading: isLoadingConnections
  } = useQuery<SchoolConnection[]>({
    queryKey: [`/api/students/${studentId}/connections`],
    enabled: !!studentId
  });

  // Fetch student event registrations
  const { 
    data: eventRegistrations,
    isLoading: isLoadingRegistrations
  } = useQuery<EventRegistration[]>({
    queryKey: [`/api/students/${studentId}/event-registrations`],
    enabled: !!studentId
  });

  // Fetch schools
  const { 
    data: schools,
    isLoading: isLoadingSchools
  } = useQuery<{ schools: School[] }>({
    queryKey: ['/api/schools'],
  });

  // Determine if we're loading any data
  const isLoading = isLoadingConnections || isLoadingRegistrations || isLoadingSchools;

  // Get connected school IDs for filtering
  const connectedSchoolIds = connections?.map(conn => conn.schoolId) || [];
  
  // Filter connected schools
  const connectedSchools = schools?.schools.filter(
    school => connectedSchoolIds.includes(school.id)
  ) || [];

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <Sidebar 
        userType="student" 
        userName={user?.email || "Student"}
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab as 'dashboard' | 'schools' | 'events')}
      />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow">
          <div className="px-6 py-4">
            <h1 className="text-2xl font-semibold text-gray-800">Student Dashboard</h1>
          </div>
        </header>
        
        <main className="p-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <>
                  {/* Welcome Banner */}
                  <Card className="mb-6">
                    <CardContent className="pt-6">
                      <h2 className="text-xl font-semibold mb-2">Welcome back!</h2>
                      <p className="text-gray-600">Here's what's happening with your connected schools.</p>
                    </CardContent>
                  </Card>
                  
                  {/* Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                            <svg className="h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                            </svg>
                          </div>
                          <div className="ml-5">
                            <h3 className="text-lg font-semibold text-gray-800">{connectedSchools.length}</h3>
                            <p className="text-sm text-gray-600">Connected Schools</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                            <svg className="h-6 w-6 text-green-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <div className="ml-5">
                            <h3 className="text-lg font-semibold text-gray-800">{eventRegistrations?.length || 0}</h3>
                            <p className="text-sm text-gray-600">Registered Events</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Events Section */}
                  <EventList 
                    registrations={eventRegistrations || []} 
                    title="Upcoming Events" 
                    className="mb-6"
                  />
                  
                  {/* Connected Schools Section */}
                  <div className="bg-white rounded-lg shadow">
                    <div className="px-6 py-4 border-b">
                      <h2 className="text-xl font-semibold">Connected Schools</h2>
                    </div>
                    <div className="p-6">
                      {connectedSchools.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                          {connectedSchools.map(school => (
                            <SchoolCard key={school.id} school={school} />
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-center py-8">
                          You haven't connected with any schools yet. Explore schools and connect with them to see their events.
                        </p>
                      )}
                    </div>
                  </div>
                </>
              )}

              {activeTab === 'schools' && (
                <div className="bg-white rounded-lg shadow">
                  <div className="px-6 py-4 border-b">
                    <h2 className="text-xl font-semibold">Available Schools</h2>
                  </div>
                  <div className="p-6">
                    {schools?.schools.length ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {schools.schools.map(school => (
                          <SchoolCard 
                            key={school.id} 
                            school={school} 
                            isConnected={connectedSchoolIds.includes(school.id)}
                            studentId={studentId}
                          />
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-center py-8">No schools found.</p>
                    )}
                  </div>
                </div>
              )}

              {activeTab === 'events' && (
                <EventList 
                  registrations={eventRegistrations || []} 
                  title="Your Registered Events" 
                  className="mb-6"
                  showAll={true}
                />
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
