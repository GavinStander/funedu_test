import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  RegisterStudent, 
  RegisterSchool 
} from "@shared/schema";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  StudentRegistrationForm 
} from "@/components/forms/student-registration-form";
import { 
  SchoolRegistrationForm 
} from "@/components/forms/school-registration-form";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function RegistrationPage() {
  const [_, setLocation] = useLocation();
  const { user, registerStudentMutation, registerSchoolMutation } = useAuth();
  const [registrationType, setRegistrationType] = useState<"student" | "school">("student");

  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const handleStudentRegistration = (data: RegisterStudent) => {
    registerStudentMutation.mutate(data);
  };

  const handleSchoolRegistration = (data: RegisterSchool) => {
    registerSchoolMutation.mutate(data);
  };

  const goBackToLogin = () => {
    setLocation("/auth");
  };

  return (
    <div className="min-h-screen flex justify-center items-center p-6 bg-gray-50">
      <div className="w-full max-w-4xl">
        <Button 
          variant="ghost" 
          className="mb-4" 
          onClick={goBackToLogin}
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Login
        </Button>
        
        <Card>
          <CardContent className="p-0">
            <div className="p-6 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-800">Register with EduConnect</h2>
              </div>
            </div>
            
            <Tabs 
              defaultValue="student" 
              onValueChange={(value) => setRegistrationType(value as "student" | "school")}
              className="p-6"
            >
              <TabsList className="grid grid-cols-2 mb-6">
                <TabsTrigger value="student">Student Registration</TabsTrigger>
                <TabsTrigger value="school">School Registration</TabsTrigger>
              </TabsList>
              
              <TabsContent value="student">
                <StudentRegistrationForm 
                  onSubmit={handleStudentRegistration} 
                  isPending={registerStudentMutation.isPending}
                />
              </TabsContent>
              
              <TabsContent value="school">
                <SchoolRegistrationForm 
                  onSubmit={handleSchoolRegistration} 
                  isPending={registerSchoolMutation.isPending}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
