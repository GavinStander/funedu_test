import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/shared/sidebar";
import StudentTable from "@/components/admin/student-table";
import SchoolTable from "@/components/admin/school-table";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'schools' | 'events'>('dashboard');

  // Fetch students
  const { 
    data: studentsData, 
    isLoading: isLoadingStudents 
  } = useQuery<{students: any[], count: number}>({
    queryKey: ['/api/students'],
  });

  // Fetch schools
  const { 
    data: schoolsData, 
    isLoading: isLoadingSchools 
  } = useQuery<{schools: any[], count: number}>({
    queryKey: ['/api/schools'],
  });

  const isLoading = isLoadingStudents || isLoadingSchools;

  // Stats for dashboard
  const totalStudents = studentsData?.count || 0;
  const totalSchools = schoolsData?.count || 0;

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <Sidebar 
        userType="admin" 
        userName={user?.email || "Admin"}
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab as 'dashboard' | 'students' | 'schools' | 'events')}
      />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow">
          <div className="px-6 py-4">
            <h1 className="text-2xl font-semibold text-gray-800">Admin Dashboard</h1>
          </div>
        </header>
        
        <main className="p-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <>
                  {/* Platform Overview */}
                  <Card className="mb-6">
                    <div className="px-6 py-4 border-b">
                      <h2 className="text-xl font-semibold">Platform Overview</h2>
                    </div>
                    <div className="p-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        <div className="bg-purple-50 rounded-lg p-5">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 bg-purple-100 rounded-md p-3">
                              <svg className="h-6 w-6 text-purple-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                              </svg>
                            </div>
                            <div className="ml-5">
                              <h3 className="text-lg font-semibold text-gray-800">{totalStudents}</h3>
                              <p className="text-sm text-gray-600">Total Students</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="bg-blue-50 rounded-lg p-5">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                              <svg className="h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                              </svg>
                            </div>
                            <div className="ml-5">
                              <h3 className="text-lg font-semibold text-gray-800">{totalSchools}</h3>
                              <p className="text-sm text-gray-600">Total Schools</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                  
                  {/* Schools Preview */}
                  <Card className="mb-6">
                    <div className="px-6 py-4 border-b flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Schools</h2>
                    </div>
                    <div className="p-6">
                      <SchoolTable schools={schoolsData?.schools || []} limit={5} />
                    </div>
                  </Card>
                  
                  {/* Students Preview */}
                  <Card>
                    <div className="px-6 py-4 border-b flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Students</h2>
                    </div>
                    <div className="p-6">
                      <StudentTable students={studentsData?.students || []} limit={5} />
                    </div>
                  </Card>
                </>
              )}

              {activeTab === 'students' && (
                <Card>
                  <div className="px-6 py-4 border-b">
                    <h2 className="text-xl font-semibold">All Students</h2>
                  </div>
                  <div className="p-6">
                    <StudentTable students={studentsData?.students || []} />
                  </div>
                </Card>
              )}

              {activeTab === 'schools' && (
                <Card>
                  <div className="px-6 py-4 border-b">
                    <h2 className="text-xl font-semibold">All Schools</h2>
                  </div>
                  <div className="p-6">
                    <SchoolTable schools={schoolsData?.schools || []} />
                  </div>
                </Card>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
