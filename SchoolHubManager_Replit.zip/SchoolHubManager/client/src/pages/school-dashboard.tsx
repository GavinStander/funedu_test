import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import Sidebar from "@/components/shared/sidebar";
import EventForm from "@/components/school/event-form";
import EventTable from "@/components/school/event-table";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Loader2, ChevronRight } from "lucide-react";
import { Event, SchoolConnection } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function SchoolDashboard() {
  const { user } = useAuth();
  const schoolId = user?.schoolId;

  // Fetch school details
  const { data: school } = useQuery({
    queryKey: [`/api/schools/${schoolId}`],
    enabled: !!schoolId
  });
  
  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'events'>('dashboard');
  const [isEventFormOpen, setIsEventFormOpen] = useState(false);

  // Fetch school's events
  const { 
    data: events,
    isLoading: isLoadingEvents,
    refetch: refetchEvents
  } = useQuery<Event[]>({
    queryKey: [`/api/schools/${schoolId}/events`],
    enabled: !!schoolId
  });

  // Fetch school's connections (connected students)
  const { 
    data: connections,
    isLoading: isLoadingConnections 
  } = useQuery<SchoolConnection[]>({
    queryKey: [`/api/schools/${schoolId}/connections`],
    enabled: !!schoolId
  });

  const isLoading = isLoadingEvents || isLoadingConnections;

  // Calculate stats for dashboard
  const activeEvents = events?.length || 0;
  const connectedStudents = connections?.length || 0;

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Sidebar */}
      <Sidebar 
        userType="school" 
        userName={user?.email || "School"}
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab as 'dashboard' | 'students' | 'events')}
      />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <header className="bg-white shadow">
          <div className="px-6 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-800">{school?.name || "School"} Dashboard</h1>
            <Dialog open={isEventFormOpen} onOpenChange={setIsEventFormOpen}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">Create Event</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Create New Event</DialogTitle>
                </DialogHeader>
                <EventForm 
                  schoolId={schoolId || 0} 
                  onSuccess={() => {
                    setIsEventFormOpen(false);
                    refetchEvents();
                  }} 
                />
              </DialogContent>
            </Dialog>
          </div>
        </header>
        
        <main className="p-6">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-green-600" />
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && (
                <>
                  {/* Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                            <svg className="h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                          </div>
                          <div className="ml-5">
                            <h3 className="text-lg font-semibold text-gray-800">{connectedStudents}</h3>
                            <p className="text-sm text-gray-600">Connected Students</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                            <svg className="h-6 w-6 text-green-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                          </div>
                          <div className="ml-5">
                            <h3 className="text-lg font-semibold text-gray-800">{activeEvents}</h3>
                            <p className="text-sm text-gray-600">Active Events</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {/* Upcoming Events */}
                  <Card className="mb-6">
                    <div className="px-6 py-4 border-b flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Manage Events</h2>
                      <Button 
                        variant="link" 
                        onClick={() => setActiveTab('events')}
                        className="text-green-600 hover:text-green-700 flex items-center gap-1"
                      >
                        View All
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="p-6">
                      <EventTable 
                        events={events || []} 
                        onEventCreated={() => refetchEvents()}
                        limit={5}
                      />
                    </div>
                  </Card>
                  
                  {/* Connected Students */}
                  <Card>
                    <div className="px-6 py-4 border-b flex justify-between items-center">
                      <h2 className="text-xl font-semibold">Recent Student Connections</h2>
                      <Button 
                        variant="link" 
                        onClick={() => setActiveTab('students')}
                        className="text-green-600 hover:text-green-700 flex items-center gap-1"
                      >
                        View All
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="p-6">
                      {connections && connections.length > 0 ? (
                        <div className="divide-y divide-gray-200">
                          {connections.slice(0, 5).map((connection) => (
                            <div key={connection.id} className="py-3 flex items-center">
                              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-primary font-semibold mr-3">
                                <span>S</span>
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-gray-900">Student ID: {connection.studentId}</p>
                                <p className="text-xs text-gray-500">
                                  Status: <Badge variant={connection.status === 'connected' ? 'default' : 'outline'}>
                                    {connection.status}
                                  </Badge>
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-center py-4">No student connections yet.</p>
                      )}
                    </div>
                  </Card>
                </>
              )}

              {activeTab === 'events' && (
                <Card>
                  <div className="px-6 py-4 border-b flex justify-between items-center">
                    <h2 className="text-xl font-semibold">All Events</h2>
                    <Dialog open={isEventFormOpen} onOpenChange={setIsEventFormOpen}>
                      <DialogTrigger asChild>
                        <Button className="bg-green-600 hover:bg-green-700">Create Event</Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                          <DialogTitle>Create New Event</DialogTitle>
                        </DialogHeader>
                        <EventForm 
                          schoolId={schoolId || 0} 
                          onSuccess={() => {
                            setIsEventFormOpen(false);
                            refetchEvents();
                          }} 
                        />
                      </DialogContent>
                    </Dialog>
                  </div>
                  <div className="p-6">
                    <EventTable 
                      events={events || []} 
                      onEventCreated={() => refetchEvents()}
                      showAll={true}
                    />
                  </div>
                </Card>
              )}

              {activeTab === 'students' && (
                <Card>
                  <div className="px-6 py-4 border-b">
                    <h2 className="text-xl font-semibold">Connected Students</h2>
                  </div>
                  <div className="p-6">
                    {connections && connections.length > 0 ? (
                      <div className="divide-y divide-gray-200">
                        {connections.map((connection) => (
                          <div key={connection.id} className="py-3 flex items-center">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-primary font-semibold mr-3">
                              <span>S</span>
                            </div>
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-900">Student ID: {connection.studentId}</p>
                              <p className="text-xs text-gray-500">
                                Connected on: {new Date(connection.connectedAt).toLocaleDateString()}
                              </p>
                            </div>
                            <Badge variant={connection.status === 'connected' ? 'default' : 'outline'}>
                              {connection.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-center py-8">No student connections yet.</p>
                    )}
                  </div>
                </Card>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}
