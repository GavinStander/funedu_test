import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { LoginForm } from "@/components/forms/login-form";
import { useAuth } from "@/hooks/use-auth";
import { LoginCredentials } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

export default function AuthPage() {
  const [_, setLocation] = useLocation();
  const { user, loginMutation } = useAuth();
  const [userType, setUserType] = useState<string>("student");

  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const handleLogin = (data: LoginCredentials) => {
    loginMutation.mutate(data);
  };

  const handleShowRegistration = () => {
    setLocation("/register");
  };

  const handleSwitchUserType = (type: string) => {
    setUserType(type);
    // In a real application, you might want to set some indicator of which type of user is logging in
  };

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      {/* Hero Image */}
      <div
        className="hidden md:block bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1500&q=80')",
        }}
      ></div>

      {/* Login Form */}
      <div className="flex flex-col justify-center items-center p-8">
        <div className="w-full max-w-md">
          <div className="mb-10 text-center">
            <h1 className="text-3xl font-bold text-primary mb-2">EduConnect</h1>
            <p className="text-gray-600">Access your educational dashboard</p>
          </div>

          <Card>
            <CardContent className="pt-6">
              <h2 className="text-2xl font-semibold mb-6">Sign In</h2>

              <LoginForm
                onSubmit={handleLogin}
                isPending={loginMutation.isPending}
                onShowRegistration={handleShowRegistration}
                onSwitchUserType={handleSwitchUserType}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
