import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, registerStudentSchema, registerSchoolSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "developmentSecretDoNotUseInProduction",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUserWithProfile(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Register student
  app.post("/api/register/student", async (req, res, next) => {
    try {
      // Validate the request data
      const validatedData = registerStudentSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create the user
      const user = await storage.createUser({
        username: validatedData.username,
        email: validatedData.email,
        password: await hashPassword(validatedData.password),
        role: 'student'
      });
      
      // Create the student profile
      const studentProfile = await storage.createStudentProfile({
        userId: user.id,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
        grade: validatedData.grade,
      });
      
      // Log the user in
      req.login({ ...user, studentProfile }, (err) => {
        if (err) return next(err);
        return res.status(201).json({ ...user, studentProfile });
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      next(error);
    }
  });
  
  // Register school
  app.post("/api/register/school", async (req, res, next) => {
    try {
      // Validate the request data
      const validatedData = registerSchoolSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(validatedData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      // Create the user
      const user = await storage.createUser({
        username: validatedData.username,
        email: validatedData.email,
        password: await hashPassword(validatedData.password),
        role: 'school'
      });
      
      // Create the school profile
      const school = await storage.createSchool({
        userId: user.id,
        name: validatedData.name,
        type: validatedData.type,
        district: validatedData.district,
        adminFirstName: validatedData.adminFirstName,
        adminLastName: validatedData.adminLastName,
        adminEmail: validatedData.adminEmail,
        adminPhone: validatedData.adminPhone,
        address: validatedData.address,
        city: validatedData.city,
        state: validatedData.state,
        zipCode: validatedData.zipCode,
        description: validatedData.description
      });
      
      // Log the user in
      req.login({ ...user, school }, (err) => {
        if (err) return next(err);
        return res.status(201).json({ ...user, school });
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      next(error);
    }
  });

  // Login route
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, async (err) => {
        if (err) {
          return next(err);
        }
        
        // Get the full user profile
        const userWithProfile = await storage.getUserWithProfile(user.id);
        return res.status(200).json(userWithProfile);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    res.json(req.user);
  });
}
