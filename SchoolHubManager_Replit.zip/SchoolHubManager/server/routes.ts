import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertEventSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Get all schools
  app.get('/api/schools', async (req, res, next) => {
    try {
      const schools = await storage.getAllSchools();
      return res.status(200).json(schools);
    } catch (error) {
      next(error);
    }
  });

  // Get school by ID
  app.get('/api/schools/:id', async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid school ID" });
      }
      
      const school = await storage.getSchool(id);
      if (!school) {
        return res.status(404).json({ message: "School not found" });
      }
      
      return res.status(200).json(school);
    } catch (error) {
      next(error);
    }
  });

  // Get events by school ID
  app.get('/api/schools/:id/events', async (req, res, next) => {
    try {
      const schoolId = parseInt(req.params.id);
      if (isNaN(schoolId)) {
        return res.status(400).json({ message: "Invalid school ID" });
      }
      
      const events = await storage.getEventsBySchool(schoolId);
      return res.status(200).json(events);
    } catch (error) {
      next(error);
    }
  });

  // Create event (requires school role)
  app.post('/api/events', async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = req.user;
      if (user.role !== 'school') {
        return res.status(403).json({ message: "Only schools can create events" });
      }
      
      // Get the school profile
      const school = await storage.getSchoolByUserId(user.id);
      if (!school) {
        return res.status(404).json({ message: "School profile not found" });
      }
      
      // Validate the event data
      const eventData = insertEventSchema.parse({
        ...req.body,
        schoolId: school.id
      });
      
      // Create the event
      const event = await storage.createEvent(eventData);
      return res.status(201).json(event);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: fromZodError(error).message });
      }
      next(error);
    }
  });

  // Get all events
  app.get('/api/events', async (req, res, next) => {
    try {
      const events = await storage.getAllEvents();
      return res.status(200).json(events);
    } catch (error) {
      next(error);
    }
  });

  // Get event by ID
  app.get('/api/events/:id', async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      return res.status(200).json(event);
    } catch (error) {
      next(error);
    }
  });

  // Register for an event (requires student role)
  app.post('/api/events/:id/register', async (req, res, next) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = req.user;
      if (user.role !== 'student') {
        return res.status(403).json({ message: "Only students can register for events" });
      }
      
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Get the student profile
      const studentProfile = await storage.getStudentProfileByUserId(user.id);
      if (!studentProfile) {
        return res.status(404).json({ message: "Student profile not found" });
      }
      
      // Check if the event exists
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Register for the event
      const registration = await storage.registerForEvent({
        eventId,
        studentId: studentProfile.id
      });
      
      return res.status(201).json(registration);
    } catch (error) {
      next(error);
    }
  });

  // Get event registrations
  app.get('/api/events/:id/registrations', async (req, res, next) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const registrations = await storage.getEventRegistrations(eventId);
      return res.status(200).json(registrations);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
