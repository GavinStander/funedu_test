
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import pg from 'pg';
const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL environment variable is required");
}

// Create postgres client for Drizzle ORM
const queryClient = postgres(process.env.DATABASE_URL);
export const db = drizzle(queryClient);

// Create the standard pool for session store and other direct postgres access
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});
